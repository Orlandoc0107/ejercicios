

def suma(a, b):
    respuesta = a+b
    print (int (respuesta))

def restar(a, b):
    respuesta = a-b
    print (int (respuesta))

def multiplicar(a, b):
    respuesta = a*b
    print (int (respuesta))

def dividir(a, b):
    respuesta = a/b
    print (int (respuesta))
